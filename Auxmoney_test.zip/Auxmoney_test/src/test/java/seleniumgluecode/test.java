package seleniumgluecode;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;

public class test {
    public static WebDriver driver;
    
    //************************Login page********************************//
    
    @Given("^user is on loginpage$")
    public void user_is_on_login() throws Throwable {     
    	System.setProperty("webdriver.chrome.driver","C:/Users/Sri/eclipse-workspace/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.get("https://www.saucedemo.com/");
        driver.manage().window().maximize();
    }
    
    @When("^user enters Username and Password$")
    public void login_Credentials() throws Throwable {
    	driver.findElement(By.id("user-name")).sendKeys("standard_user");
    	driver.findElement(By.id("password")).sendKeys("secret_sauce");
    	driver.findElement(By.id("login-button")).click();
    }
    
    @Then("^user logs in successfully$") 
    public void assert_url() throws Throwable {
    	String exp_message = "https://www.saucedemo.com/inventory.html";
    	String url1 = driver.getCurrentUrl();
        Assert.assertEquals(exp_message, url1);
        
          
    }      
    //************************Add Delete product********************************//
    
    @Given("^User is on products page$")
    public void assert_url_productpage() throws Throwable {
    	//String exp_message2 = "https://www.saucedemo.com/inventory.html";
    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	//String url2 = driver.getCurrentUrl();
       // Assert.assertEquals(exp_message2, url2);
    }
    
    @When("^User clicks on product add to cart$")
    public void add_to_cart() throws Throwable {
    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	driver.findElement(By.xpath("//*[@id=\"inventory_container\"]/div/div[1]/div[3]/button")).click();
    }
    
    @And("^clicks on cart$")
    public void click_on_cart() throws Throwable {
    	driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a")).click();
    }
    
    @Then("^product is added to cart$")
    public void added_to_cart() throws Throwable {
    	driver.findElement(By.xpath("//*[@id=\"item_4_title_link\"]")).isDisplayed();
    }
    
    @Given ("^User is on Your cart page$")
    public void assert_url_cart() throws Throwable {
    	String exp_message3 = "https://www.saucedemo.com/cart.html";
    	String url3 = driver.getCurrentUrl();
        Assert.assertEquals(exp_message3, url3);
    }
    
  //************************Cart Page********************************//
    

    @When("^User clicks on the product name$")
    public void product () throws Throwable {
    	driver.findElement(By.xpath("//*[@id=\"item_4_title_link\"]")).click();
    }
    
    @Then("^product details is open$")
    public void prouct_description() throws Throwable {
    	driver.findElement(By.xpath("//*[@id=\"inventory_item_container\"]/div/div/div/div[2]")).isDisplayed();
    }
    	
    	
    @And("^details closes on clicking back$")
    public void back() throws Throwable {
    	//*[@id="inventory_item_container"]/div/button
    	  driver.findElement(By.xpath("//*[@id=\"inventory_item_container\"]/div/button")).click();
    }
    
//************************Checkout Page********************************//
    

    @When("^User clicks on Checkout button$")
    public void  checkout() throws Throwable {
        driver.findElement(By.linkText("CHECKOUT")).click();
    }
    
    @And("^User provides Firstname, Lastname and zipcode$")
    public void prouct_description_page() throws Throwable {
    	 driver.findElement(By.id("first-name")).sendKeys("Elin");
         driver.findElement(By.id("last-name")).sendKeys("Lu");
         driver.findElement(By.id("postal-code")).sendKeys("5053");
    }
    	
    	
    @Then("^User clicks continue button$")
    public void Continue() throws Throwable {
    	  driver.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[2]/input")).click();
    }
    @And("^User lands on Overview page$")
    	public void assert_url_overview() throws Throwable {
        	String exp_message = "https://www.saucedemo.com/checkout-step-two.html";
        	String url1 = driver.getCurrentUrl();
            Assert.assertEquals(exp_message, url1);
    	
    }
    	
    	
    @And("^User clicks on Finish button$")
    public void click_back() throws Throwable {
    	  driver.findElement(By.linkText("FINISH")).click();
    }
    
    @Then("^User purchases the product successfuly$")
    public void success_message() throws Throwable {
    	  String success_msg1="THANK YOU FOR YOUR ORDER";
          String success_msg2="Your order has been dispatched, and will arrive just as fast as the pony can get there!";
    	  String exp1=driver.findElement(By.xpath("//*[@id=\"checkout_complete_container\"]/h2")).getText();
    	  String exp2=driver.findElement(By.xpath("//*[@id=\"checkout_complete_container\"]/div")).getText();
    	  Assert.assertEquals(success_msg1, exp1);
    	  Assert.assertEquals(success_msg2, exp2);
    	  
    }  
        
//************************logout Page********************************//
    @Given("^User is on products page again$")
    public void user_is_on_products_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
    }
    
    @When("^User can click on menu and logout option$")
    public void  left_menu() throws Throwable {
    	driver.findElement(By.xpath("//*[@id=\"menu_button_container\"]/div/div[3]/div/button")).click();
    }
    
    @And("^User logs out of application$")
    public void logout() throws Throwable {
    	driver.findElement(By.linkText("Logout")).click();
        driver.quit();
    }
    	

}

